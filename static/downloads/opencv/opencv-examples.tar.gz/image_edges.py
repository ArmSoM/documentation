#!/usr/bin/env python3
"""Run the guide's original Gaussian/Canny image example and show its output."""
import argparse
import os
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--no-display', action='store_true', help='Save the image without opening a window')
args = parser.parse_args()
os.environ.setdefault('DISPLAY', ':0')
os.environ.setdefault('QT_XCB_GL_INTEGRATION', 'none')
import cv2

samples = Path(__file__).resolve().parent / 'samples'
image = cv2.imread(str(samples / 'bbb-frame.jpg'))
if image is None:
    raise SystemExit('Cannot read samples/bbb-frame.jpg. Prepare the input image using the test media section of the guide.')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 0), 60, 160)
output = samples / 'bbb-edges.png'
if not cv2.imwrite(str(output), edges):
    raise RuntimeError('Cannot save the edge image')
print('IMAGE_OK', edges.shape, cv2.countNonZero(edges), flush=True)
print('Saved:', output, flush=True)
if not args.no_display:
    cv2.namedWindow('Canny edges', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('Canny edges', 960, 540)
    cv2.imshow('Canny edges', edges)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
