#!/usr/bin/env bash
# Install the environment for the ArmSoM OpenCV examples; run as the desktop login user.
set -Eeuo pipefail
if [[ ${1:-} == --help ]]; then
    echo 'Usage: bash setup.sh'
    echo 'Installs APT dependencies and a local OpenCV venv, and checks MPP. Does not download or process media.'
    echo 'Run without sudo from the board desktop. Root login is also supported.'
    exit 0
fi
[[ $# == 0 ]] || { echo 'Usage: bash setup.sh' >&2; exit 1; }
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
stage='system check'
trap 'printf "\nFAILED during %s (line %s). Fix the reported error and rerun bash setup.sh.\nAPT help: https://docs.armsom.org/getting-start/apt-update#fresh-image-apt\n" "$stage" "$LINENO" >&2' ERR
fail() { printf '%s\n' "$*" >&2; exit 1; }
[[ $(uname -m) == aarch64 ]] || fail 'This setup requires a Linux ARM64 board.'
. /etc/os-release
case "$ID:$VERSION_ID" in
    debian:12|ubuntu:22.04) ;;
    *) fail "Supported setup targets: Debian 12 and Ubuntu 22.04; found $ID $VERSION_ID." ;;
esac
[[ -z ${SUDO_USER:-} || ${SUDO_USER} == root ]] || fail 'Run bash setup.sh without sudo, as your desktop login user. It requests sudo only for APT.'
admin=()
if (( EUID != 0 )); then
    command -v sudo >/dev/null || fail 'sudo is required to install system dependencies.'
    admin=(sudo)
fi
printf '[1/4] System: %s %s, ARM64\n' "$ID" "$VERSION_ID"

stage='APT dependencies'
packages=(python3-venv curl ffmpeg x11-xserver-utils gstreamer1.0-tools
    gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad
    python3-gi gir1.2-gstreamer-1.0 gir1.2-gst-plugins-base-1.0)
missing=()
for package in "${packages[@]}"; do
    if [[ $(dpkg-query -W -f='${Status}' "$package" 2>/dev/null || true) != 'install ok installed' ]]; then
        missing+=("$package")
    fi
done
echo '[2/4] Installing missing system dependencies'
if (( ${#missing[@]} )); then
    "${admin[@]}" apt-get update -o APT::Update::Error-Mode=any
    "${admin[@]}" apt-get install -y "${missing[@]}"
fi

stage='Python environment'
echo '[3/4] Preparing local OpenCV 5.0.0 environment'
# Repeating venv creation repairs an interrupted ensurepip step without deleting it.
/usr/bin/python3 -m venv venv
if ! ./venv/bin/python -c 'import cv2; from importlib.metadata import version; assert cv2.__version__ == "5.0.0" and version("opencv-python") == "5.0.0.93"' 2>/dev/null; then
    ./venv/bin/python -m pip install --only-binary=:all: 'opencv-python==5.0.0.93'
fi

stage='MPP and Python bindings'
echo '[4/4] Checking hardware decoding and Python bindings'
for element in mppvideodec qtdemux h264parse videoconvert appsink; do
    gst-inspect-1.0 "$element" >/dev/null 2>&1 || fail "Missing GStreamer element: $element. Use the official desktop image with the Rockchip MPP plugin for your board."
done
./venv/bin/python - <<'PY'
import sys
import cv2
sys.path.append('/usr/lib/python3/dist-packages')
import gi
gi.require_version('Gst', '1.0')
gi.require_version('GstVideo', '1.0')
from gi.repository import Gst, GstVideo
print('OpenCV', cv2.__version__, '| MPP plugins and GStreamer bindings OK')
PY

printf '\nENV_READY: %s\nEnvironment installed. Prepare the test media using the guide before running an example.\n' "$PWD"
if ! DISPLAY="${DISPLAY:-:0}" xrandr --current >/dev/null 2>&1; then
    echo 'Display is not accessible in this terminal. Run previews from the logged-in HDMI desktop terminal.'
fi
