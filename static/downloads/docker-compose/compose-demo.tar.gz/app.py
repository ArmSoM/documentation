import os
import platform
import socket

import redis
from flask import Flask, jsonify, Response

PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ArmSoM Compose Lab</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#edf3f5;color:#173440;font-family:Arial,sans-serif}
main{max-width:1040px;margin:64px auto;padding:0 24px}header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #c7d8de;padding-bottom:24px}
.brand{font-weight:700;font-size:26px;color:#008c9b}.status{font-size:14px}
h1{font-size:42px;letter-spacing:-1px;margin:42px 0 12px}p{line-height:1.6;color:#526a73}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-top:32px}.card{background:#fff;border:1px solid #d3e1e6;border-radius:16px;padding:32px}
h2{font-size:18px;margin:0 0 20px}.count{font-size:88px;font-weight:700;line-height:1.2;margin:24px 0;color:#008c9b}
button{background:#007f8c;color:white;border:0;border-radius:8px;padding:14px 24px;font-size:16px;cursor:pointer}
button:disabled{opacity:.5}dl{margin:0}dt{color:#647b84;font-size:13px;margin-top:20px}dd{margin:5px 0;font-family:monospace;font-size:17px;word-break:break-all}
.note{font-size:14px}footer{margin-top:24px;color:#526a73;font-size:14px}
@media(max-width:700px){.grid{grid-template-columns:1fr}main{margin:24px auto}h1{font-size:32px}}
</style>
</head>
<body><main>
<header><span class="brand">ArmSoM</span><span id="status" class="status">Connecting…</span></header>
<h1>Docker Compose Lab</h1>
<p>A Python web service and Redis, running together on your board.</p>
<div class="grid">
<section class="card"><h2>Persistent counter</h2><div id="count" class="count">—</div><button id="increment">Add one</button><p class="note">Stored in Redis. Recreating the containers keeps this value.</p></section>
<section class="card"><h2>Running services</h2><dl><dt>Application version</dt><dd id="version">—</dd><dt>Container architecture</dt><dd id="architecture">—</dd><dt>Web container</dt><dd id="container">—</dd><dt>Database service</dt><dd id="database">—</dd></dl></section>
</div><footer>Browser → board port 8080 → web:8000 → redis:6379 → named volume</footer>
</main>
<script>
const statusLabel = document.getElementById("status");
const button = document.getElementById("increment");
async function request(url, options) {
  const response = await fetch(url, options);
  if (!response.ok) throw new Error("Service unavailable — retry after Redis recovers");
  return response.json();
}
async function refresh() {
  try {
    const data = await request("/api/state");
    for (const key of ["count", "version", "architecture", "container", "database"]) {
      document.getElementById(key).textContent = data[key];
    }
    statusLabel.textContent = "Web + Redis connected";
  } catch (error) {
    statusLabel.textContent = error.message;
  }
}
button.addEventListener("click", async () => {
  button.disabled = true;
  try {
    await request("/api/increment", {method: "POST"});
    await refresh();
  } catch (error) {
    statusLabel.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
refresh();
setInterval(refresh, 5000);
</script></body></html>
"""

app = Flask(__name__)
database = redis.Redis(
    host=os.environ.get("REDIS_HOST", "redis"),
    port=6379,
    decode_responses=True,
    socket_connect_timeout=2,
    socket_timeout=2,
)


@app.errorhandler(redis.exceptions.RedisError)
def database_error(error):
    app.logger.warning("Redis unavailable: %s", error)
    return jsonify(error="Redis unavailable. Retry after the service recovers."), 503


@app.get("/")
def index():
    return Response(PAGE, mimetype="text/html")


@app.get("/health")
def health():
    database.ping()
    return jsonify(status="ok")


@app.get("/api/state")
def state():
    return jsonify(
        count=int(database.get("visits") or 0),
        version=os.environ.get("APP_VERSION", "v1"),
        architecture=platform.machine(),
        container=socket.gethostname(),
        database="redis:6379",
    )


@app.post("/api/increment")
def increment():
    return jsonify(count=database.incr("visits"))
