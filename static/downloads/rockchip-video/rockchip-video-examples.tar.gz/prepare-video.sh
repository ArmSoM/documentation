#!/usr/bin/env bash
set -euo pipefail

mkdir -p "$HOME/rockchip-video"
cd "$HOME/rockchip-video"

if [ -e sintel-1080p.mp4 ]; then
  printf '%s\n' 'sintel-1080p.mp4 already exists; rename it before running again.' >&2
  exit 1
fi

if [ ! -f sintel-source.mp4 ]; then
  curl -fL https://download.blender.org/durian/trailer/sintel_trailer-1080p.mp4 \
    -o sintel-source.mp4.part
  mv sintel-source.mp4.part sintel-source.mp4
fi

ffmpeg -nostdin -n -ss 12 -i sintel-source.mp4 -t 8 -an \
  -vf scale=1920:1080 -r 30 -c:v libx264 -preset ultrafast \
  -pix_fmt yuv420p sintel-1080p.mp4

printf 'Source: %s/sintel-source.mp4\nClip: %s/sintel-1080p.mp4\n' "$PWD" "$PWD"
