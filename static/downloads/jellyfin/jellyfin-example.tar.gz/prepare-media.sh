#!/usr/bin/env bash
# Prepare a 60-second SDR test clip. Run as root after installing Jellyfin.
set -euo pipefail
BASE=${1:-/srv/jellyfin}
FFMPEG=/usr/lib/jellyfin-ffmpeg/ffmpeg
for cmd in curl unzip; do command -v "$cmd" >/dev/null || { echo "Install $cmd first." >&2; exit 1; }; done
test -x "$FFMPEG" || { echo "Install Jellyfin and jellyfin-ffmpeg first." >&2; exit 1; }
mkdir -p "$BASE/downloads" "$BASE/media"
ZIP="$BASE/downloads/tears-of-steel.zip"
SOURCE="$BASE/downloads/tears_of_steel_1080p.mov"
OUTPUT="$BASE/media/tears-of-steel-1080p.mp4"
if [ ! -f "$ZIP" ]; then
  curl -fL --retry 3 --connect-timeout 20 \
    https://download.blender.org/demo/movies/ToS/tears_of_steel_1080p.mov.zip \
    -o "$ZIP.part"
  mv "$ZIP.part" "$ZIP"
fi
if [ ! -f "$SOURCE" ]; then unzip -j "$ZIP" -d "$BASE/downloads"; fi
if [ ! -f "$OUTPUT" ]; then
  "$FFMPEG" -hide_banner -y -ss 60 -i "$SOURCE" -t 60 \
    -map 0:v:0 -map 0:a:0 -vf 'pad=1920:1080:0:140:black' \
    -c:v libx264 -threads 4 -preset veryfast -crf 20 -pix_fmt yuv420p \
    -c:a aac -b:a 128k -movflags +faststart \
    -metadata title='Tears of Steel - ArmSoM 60s test' \
    -metadata comment='Excerpt 01:00-02:00; black bars added. (CC) Blender Foundation | mango.blender.org | CC BY 3.0' \
    "$BASE/media/tears-of-steel-1080p.tmp.mp4"
  mv "$BASE/media/tears-of-steel-1080p.tmp.mp4" "$OUTPUT"
fi
POSTER="$BASE/media/tears-of-steel-1080p-poster.jpg"
if [ ! -f "$POSTER" ]; then
  "$FFMPEG" -hide_banner -loglevel error -ss 12 -i "$OUTPUT" \
    -frames:v 1 -update 1 "$POSTER"
fi
chmod 755 "$BASE" "$BASE/media"
chmod 644 "$OUTPUT" "$POSTER"
printf '\nReady: %s\nJellyfin library folder: %s/media\n' "$OUTPUT" "$BASE"
"${FFMPEG%/*}/ffprobe" -v error -select_streams v:0 \
  -show_entries stream=codec_name,width,height,r_frame_rate \
  -show_entries format=duration,size -of default=noprint_wrappers=1 "$OUTPUT"
