ArmSoM Jellyfin example

Run after installing Jellyfin, curl and unzip:
  sudo bash prepare-media.sh

Default library: /srv/jellyfin/media
Optional base directory: sudo bash prepare-media.sh /path/to/jellyfin
Existing final output is preserved. Download and preparation may take several minutes.
The original ZIP and MOV stay in the downloads directory; keep about 2 GB free.
Do not add the downloads directory as a Jellyfin library.

Media attribution:
Tears of Steel (2012), (CC) Blender Foundation | mango.blender.org
https://mango.blender.org/about/
https://creativecommons.org/licenses/by/3.0/
Original download: https://download.blender.org/demo/movies/ToS/
The script extracts 01:00-02:00, adds top/bottom black bars to the original
1920x800 picture, and encodes a 1920x1080 H.264/AAC MP4 at 24 fps.
The clip is an excerpt, not the original full film. It is not included in this archive.
Screenshots in the guide show this modified test excerpt. Retain attribution when sharing.

This script prepares media only. It does not install packages, change device
permissions, create accounts, or change Jellyfin settings.
