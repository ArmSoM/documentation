"""Create a session IQ profile without rewriting the calibrated original."""
from copy import deepcopy
import json
from pathlib import Path

from .media import CameraError, Mode


def session_profile(source: Path, mode: Mode, fps: int) -> dict:
    try:
        profile = deepcopy(json.loads(source.read_text()))
    except (ValueError, UnicodeError) as exc:
        raise CameraError(f'Invalid IQ JSON: {source}') from exc
    if not isinstance(profile, dict):
        raise CameraError('Unsupported IQ schema: expected a JSON object')
    sensor = profile.get('sensor_calib', {})
    if not isinstance(sensor, dict) or not isinstance(sensor.get('resolution'), dict):
        raise CameraError('Unsupported IQ schema: sensor_calib.resolution is missing')
    sensor['resolution'].update(width=mode.width, height=mode.height)
    if 'CISMinFps' in sensor:
        sensor['CISMinFps'] = min(sensor['CISMinFps'], fps)
    found = 0

    def visit(value):
        nonlocal found
        if isinstance(value, dict):
            # ISP39 / RK3576 schema and legacy ISP30 / RK3588 schema.
            if 'sw_aeT_frmRate_mode' in value and 'sw_aeT_frmRate_val' in value:
                value.update(sw_aeT_frmRate_mode='ae_frmRate_fix_mode', sw_aeT_frmRate_val=fps)
                found += 1
            if 'isFpsFix' in value and 'FpsValue' in value:
                # ISP30's JSON parser requires numeric booleans. JSON true is
                # accepted syntactically but leaves fixed FPS disabled.
                value.update(isFpsFix=1, FpsValue=fps)
                found += 1
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    visit(profile)
    if not found:
        raise CameraError('Unsupported IQ schema: no recognised AE frame-rate settings')
    return profile


def _binned_lsc(lsc: dict, mode: Mode) -> bool:
    """Map the SDK IMX219 full-FOV 2x2 mode, preserving calibrated gains.

    1640x1232 covers the same sensor area as 3280x2464 in this IMX219 driver.
    Halve mesh coordinates, not gains. Never infer this for cropped modes.
    """
    if (mode.width, mode.height) != (1640, 1232):
        return False
    try:
        common, tables = lsc['common'], lsc['tbl']['tableAll']
        source = next(item for item in common['resolutionAll'] if item['name'] == '3280x2464')
        geometry = deepcopy(source)
        geometry['name'] = '1640x1232'
        for axis, extent in [('x', 3280), ('y', 2464)]:
            sizes = source['lsc_sect_size_' + axis]
            if len(sizes) != 16 or any(type(n) is not int or n <= 0 for n in sizes) or sum(sizes) != extent:
                return False
            position, previous, scaled = 0, 0, []
            for size in sizes:
                position += size
                end = (position + 1) // 2
                scaled.append(end - previous)
                previous = end
            geometry['lsc_sect_size_' + axis] = scaled
        original_tables = [item for item in tables if item['resolution'] == '3280x2464']
        required = {'3280x2464_' + item['name'] for illuminant in lsc['alscCoef']['illAll']
                    for item in illuminant['tableUsed']}
        if not required or not required <= {item['name'] for item in original_tables}:
            return False
        mapped = []
        for original in original_tables:
            if not original['name'].startswith('3280x2464_'):
                return False
            for channel in ('red', 'greenR', 'greenB', 'blue'):
                if len(original['lsc_samples_' + channel]['uCoeff']) != 17 * 17:
                    return False
            table = deepcopy(original)
            table['resolution'] = '1640x1232'
            table['name'] = '1640x1232_' + original['name'].split('_', 1)[1]
            mapped.append(table)
    except (KeyError, TypeError, StopIteration):
        return False
    common['resolutionAll'].append(geometry)
    common['resolutionAll_len'] = len(common['resolutionAll'])
    tables.extend(mapped)
    lsc['tbl']['tableAll_len'] = len(tables)
    return True


def configure_lsc(profile: dict, mode: Mode) -> list[str]:
    """Prepare ISP30 LSC geometry only in the private session profile.

    Reuse full-FOV calibration for the known 2x2 mode. If no valid mapping or
    matching calibration exists, disable LSC to prevent black ISP30 output.
    """
    requested = f'{mode.width}x{mode.height}'
    disabled = False
    for main in profile.get('main_scene', []) or []:
        for sub in main.get('sub_scene', []) or []:
            lsc = sub.get('scene_isp30', {}).get('lsc_v2', {})
            common = lsc.get('common', {})
            if common.get('enable') and requested not in {
                    item.get('name') for item in common.get('resolutionAll', [])}:
                if not _binned_lsc(lsc, mode):
                    common['enable'] = 0
                    disabled = True
    return ([f'LSC disabled for this session: IQ has no configuration for sensor {requested}. '
             'Lens shading may remain; use --iq-file with a calibrated profile for this mode.']
            if disabled else [])


def choose_profile(directory: Path, explicit: str | None, mode: Mode) -> Path:
    if explicit:
        path = Path(explicit).resolve()
        if not path.is_file():
            raise CameraError(f'IQ file not found: {path}')
        return path
    # Optional separately calibrated mode profiles. Never copy calibration from
    # a different SoC or silently edit LSC/CCM/noise tables.
    specific = directory / 'armsom-camera' / f'imx219-{mode.width}x{mode.height}.json'
    if specific.is_file():
        return specific
    candidates = sorted(directory.glob('imx219_*.json'))
    if len(candidates) != 1:
        raise CameraError('Expected one IMX219 IQ file in /etc/iqfiles; use --iq-file to select one')
    return candidates[0]
