"""GStreamer capture worker: finite still capture, preview and MP4 recording."""
import json
import os
from pathlib import Path
import signal
import sys
import time


def run(config: dict) -> int:
    import gi
    gi.require_version('Gst', '1.0')
    from gi.repository import Gst, GLib
    os.environ['GST_V4L2SRC_MAX_RESOLUTION'] = f"{config['width']}x{config['height']}"
    if config['action'] == 'preview':
        # Use the vendor Mali EGL/GLES stack rather than Xv or software GLX.
        os.environ.setdefault('GST_GL_PLATFORM', 'egl')
        os.environ.setdefault('GST_GL_API', 'gles2')
    Gst.init(None)
    pipeline = Gst.Pipeline.new('armsom-camera')
    elements = []
    display = None
    preview_size = None

    def add(factory, name, **properties):
        element = Gst.ElementFactory.make(factory, name)
        if element is None:
            raise RuntimeError(f'Missing GStreamer element: {factory}')
        for key, value in properties.items():
            element.set_property(key.replace('_', '-'), value)
        pipeline.add(element)
        if elements and not elements[-1].link(element):
            raise RuntimeError(f'Cannot link {elements[-1].name} -> {name}')
        elements.append(element)
        return element

    warmup = config['warmup'] if config['action'] == 'still' else 0
    count = warmup + 1 if config['action'] == 'still' else config.get('frames', 0)
    add('v4l2src', 'camera', device=config['video'], io_mode=2, num_buffers=count or -1)
    if config.get('independent_capture_pool'):
        # This ISP30 stack negotiates only two capture buffers with encoders,
        # losing every third frame. Keep v4l2src's allocation/copy fallback
        # independent of downstream pools. No frame/timestamp conversion.
        add('identity', 'capture_allocation', drop_allocation=True, signal_handoffs=False)
    caps = Gst.Caps.from_string(f"video/x-raw,format=NV12,width={config['width']},height={config['height']},framerate={config['fps']}/1")
    filtered = add('capsfilter', 'format', caps=caps)
    if config['action'] == 'still':
        add('jpegenc', 'jpeg', quality=95)
        add('filesink', 'output', location=config['output'], sync=False)
    elif config['action'] == 'video':
        add('mpph264enc', 'encoder')
        add('h264parse', 'parser')
        add('mp4mux', 'mux')
        add('filesink', 'output', location=config['output'], sync=False)
    elif config['action'] == 'test':
        add('fakesink', 'output', sync=False)
    else:
        add('queue', 'preview_queue', max_size_buffers=2, max_size_bytes=0,
            max_size_time=0, leaky=2)
        # The sink's native-size window can exceed the desktop. Bound only the
        # viewfinder; sensor/ISP caps and saved media retain the requested size.
        scale = min(1, 1280 / config['width'], 960 / config['height'])
        preview_size = [max(2, int(config[key] * scale) // 2 * 2) for key in ('width', 'height')]
        if scale < 1:
            add('glupload', 'gpu_upload')
            add('glcolorconvert', 'gpu_color')
            add('glcolorscale', 'gpu_scale')
            add('capsfilter', 'viewfinder', caps=Gst.Caps.from_string(
                f'video/x-raw(memory:GLMemory),width={preview_size[0]},height={preview_size[1]},pixel-aspect-ratio=1/1'))
        # glimagesink uploads NV12 and converts/scales on the GPU. Clock sync
        # schedules frames; EGL and the compositor handle screen presentation.
        display = add('glimagesink', 'display', sync=True,
                      max_lateness=Gst.SECOND // config['fps'], enable_last_sample=False)

    loop = GLib.MainLoop()
    state = {'frames': 0, 'first': None, 'last': None, 'error': None, 'eos_at': None}
    started = time.monotonic()
    parent = os.getppid()

    def buffer_probe(pad, info):
        now = time.monotonic()
        state['frames'] += 1
        state['last'] = now
        if state['first'] is None:
            state['first'] = now
            actual = pad.get_current_caps().get_structure(0)
            state['width'] = actual.get_value('width')
            state['height'] = actual.get_value('height')
        return Gst.PadProbeReturn.DROP if state['frames'] <= warmup else Gst.PadProbeReturn.OK

    filtered.get_static_pad('src').add_probe(Gst.PadProbeType.BUFFER, buffer_probe)

    def message(_bus, event):
        if event.type == Gst.MessageType.ERROR:
            err, debug = event.parse_error()
            state['error'] = f'{err}: {debug}'
            loop.quit()
        elif event.type == Gst.MessageType.EOS:
            loop.quit()

    def finish(*_):
        if state['eos_at'] is None:
            state['eos_at'] = time.monotonic()
            pipeline.send_event(Gst.Event.new_eos())
        return False

    def watchdog():
        now = time.monotonic()
        if os.getppid() != parent:
            finish()
        if state['eos_at'] is not None and now - state['eos_at'] > 8:
            state['error'] = 'Timed out finalizing the stream'
            loop.quit()
        elif now - (state['last'] or started) > 12:
            state['error'] = 'No camera frames for 12 seconds'
            loop.quit()
        elif config['action'] != 'still' and config['timeout'] and state['first'] is not None:
            if now - state['first'] >= config['timeout'] / 1000:
                finish()
        return True

    bus = pipeline.get_bus()
    bus.add_signal_watch()
    bus.connect('message', message)
    GLib.timeout_add(250, watchdog)
    signal.signal(signal.SIGINT, lambda *_: GLib.idle_add(finish))
    signal.signal(signal.SIGTERM, lambda *_: GLib.idle_add(finish))
    try:
        if pipeline.set_state(Gst.State.PLAYING) == Gst.StateChangeReturn.FAILURE:
            raise RuntimeError('Could not start capture')
        loop.run()
    finally:
        try:
            if display is not None:
                stats = display.get_property('sink').get_property('stats')
                state['display'] = {'backend': 'glimagesink', 'sync': True,
                                    'size': preview_size,
                                    'rendered': stats.get_value('rendered'),
                                    'dropped': stats.get_value('dropped')}
        finally:
            pipeline.set_state(Gst.State.NULL)
            bus.remove_signal_watch()
    elapsed = (state['last'] - state['first']) if state['first'] is not None else 0
    state['measured_fps'] = (state['frames'] - 1) / elapsed if elapsed > 0 else 0
    if state['frames'] <= warmup and not state['error']:
        state['error'] = 'Capture ended before a usable image was received'
    Path(config['result']).write_text(json.dumps(state, indent=2))
    if state['error']:
        print(state['error'], file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(run(json.loads(Path(sys.argv[1]).read_text())))
