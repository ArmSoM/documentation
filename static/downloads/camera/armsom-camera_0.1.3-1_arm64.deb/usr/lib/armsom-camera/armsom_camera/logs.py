"""Bound worker output and retain a limited set of private session logs."""
from contextlib import contextmanager
from datetime import datetime
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
import threading


LOG_BYTES = 1024 * 1024
HISTORY_BYTES = 64 * 1024 * 1024
HISTORY_COUNT = 20
SESSION_NAME = re.compile(r'\d{8}-\d{6}-[a-z0-9_]{8}')


def prune(root: Path, current: Path, count=HISTORY_COUNT, budget=HISTORY_BYTES):
    """Remove oldest generated sessions only; never follow a directory link."""
    sessions = []
    for path in root.iterdir():
        if SESSION_NAME.fullmatch(path.name) and not path.is_symlink() and path.is_dir():
            size = sum(item.stat().st_size for item in path.rglob('*')
                       if not item.is_symlink() and item.is_file())
            sessions.append((path.stat().st_mtime_ns, path, size))
    total, remaining = sum(item[2] for item in sessions), len(sessions)
    for _, path, size in sorted(sessions):
        if remaining <= count and total <= budget:
            break
        if path == current:
            continue
        shutil.rmtree(path)
        remaining -= 1
        total -= size


class RotatingPipe:
    """Drain native stdout continuously, keeping one current and one old file."""
    def __init__(self, path: Path, limit=LOG_BYTES):
        if limit <= 0:
            raise ValueError('Log size limit must be positive')
        self.path, self.limit, self.error = path, limit, None
        read_fd, write_fd = os.pipe()
        self.reader = os.fdopen(read_fd, 'rb', buffering=0)
        self.writer = os.fdopen(write_fd, 'wb', buffering=0)
        self.thread = threading.Thread(target=self._drain, daemon=True)

    def _drain(self):
        output = None
        size = 0
        try:
            while chunk := self.reader.read(65536):
                # If storage fails, continue consuming the pipe so that camera
                # workers cannot deadlock waiting for their stdout to drain.
                if self.error:
                    continue
                try:
                    while chunk:
                        if output is None:
                            output = self.path.open('wb')
                        if size == self.limit:
                            output.close()
                            output = None
                            os.replace(self.path, self.path.with_name(self.path.name + '.1'))
                            output = self.path.open('wb')
                            size = 0
                        part, chunk = chunk[:self.limit-size], chunk[self.limit-size:]
                        output.write(part)
                        output.flush()
                        size += len(part)
                except OSError as exc:
                    self.error = exc
        finally:
            self.reader.close()
            if output is not None:
                try:
                    output.close()
                except OSError as exc:
                    self.error = exc

    def __enter__(self):
        self.thread.start()
        return self.writer

    def __exit__(self, *_):
        self.writer.close()
        # The session stops both workers before leaving this context.
        self.thread.join(timeout=5)
        if self.thread.is_alive():
            print(f'armsom-camera: log pipe still open: {self.path}', file=sys.stderr)
        if self.error:
            print(f'armsom-camera: log storage failed: {self.error}', file=sys.stderr)


@contextmanager
def session_logs(root: Path):
    """Called under the camera lock; create/prune only on explicit capture."""
    root.mkdir(parents=True, exist_ok=True)
    if root.is_symlink():
        raise OSError(f'Log directory must not be a symlink: {root}')
    directory = Path(tempfile.mkdtemp(prefix=datetime.now().strftime('%Y%m%d-%H%M%S-'), dir=root))
    prune(root, directory)
    try:
        with RotatingPipe(directory / 'aiq.log') as aiq, RotatingPipe(directory / 'capture.log') as capture:
            yield directory, aiq, capture
    finally:
        # Retain the current failure report even when an older session was huge.
        try:
            prune(root, directory)
        except OSError as exc:
            print(f'armsom-camera: could not prune old logs: {exc}', file=sys.stderr)
