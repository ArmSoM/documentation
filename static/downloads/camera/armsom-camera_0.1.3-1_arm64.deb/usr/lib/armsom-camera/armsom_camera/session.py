"""Exclusive capture session with bounded workers and restoration on exit."""
from contextlib import contextmanager
from dataclasses import asdict
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time

from . import media
from .logs import session_logs
from .iq import choose_profile, session_profile, configure_lsc
from .media import CameraError


def ensure_idle():
    """The SDK 3A service owns all ISPs; refuse to interrupt another consumer."""
    for proc in Path('/proc').glob('[0-9]*'):
        if int(proc.name) == os.getpid():
            continue
        try:
            name = (proc / 'comm').read_text().strip()
            if name == 'rkaiq_3A_server':
                continue
            for fd in (proc / 'fd').iterdir():
                target = os.readlink(fd)
                if target.startswith(('/dev/video', '/dev/v4l-subdev')):
                    raise CameraError(f'Camera is in use by {name} (PID {proc.name}); close it first')
        except (FileNotFoundError, ProcessLookupError):
            continue


def stop_process(proc, graceful=signal.SIGTERM):
    if proc is not None and proc.poll() is None:
        proc.send_signal(graceful)
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)


@contextmanager
def camera_lock():
    with open('/run/lock/armsom-camera.lock', 'a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise CameraError('Another armsom-camera session is running') from exc
        yield


def capture(camera, mode, args):
    profile = choose_profile(Path('/etc/iqfiles'), args.iq_file, mode)
    iq = session_profile(profile, mode, args.framerate)
    warnings = configure_lsc(iq, mode)
    for warning in warnings:
        print(f'armsom-camera: warning: {warning}', file=sys.stderr)
    # Validate libraries and plugins before stopping the existing 3A service.
    required = ['v4l2src', 'capsfilter', 'identity']
    required += {'still': ['jpegenc', 'filesink'], 'video': ['mpph264enc', 'h264parse', 'mp4mux', 'filesink'],
                 'preview': ['queue', 'glupload', 'glcolorconvert', 'glcolorscale', 'glimagesink'],
                 'test': ['fakesink']}[args.action]
    for plugin in required:
        media.command('gst-inspect-1.0', plugin)
    media.command(sys.executable, '-c', 'import gi; gi.require_version("Gst","1.0"); from gi.repository import Gst')
    if args.action == 'preview' and not any(os.environ.get(k) for k in ('DISPLAY', 'WAYLAND_DISPLAY')):
        raise CameraError('Preview needs a desktop terminal (run sudo -E to preserve its display environment)')

    with camera_lock(), session_logs(Path('/var/log/armsom-camera')) as logs, \
            tempfile.TemporaryDirectory(prefix='armsom-camera-', dir='/run') as temp:
        logdir, aiq_log, capture_log = logs
        print(f'Logs: {logdir}', flush=True)
        temp = Path(temp)
        ensure_idle()
        saved = media.snapshot(camera)
        (logdir / 'restore.json').write_text(json.dumps(saved, indent=2))
        was_active = subprocess.run(['systemctl', 'is-active', '--quiet', 'rkaiq_3A.service']).returncode == 0
        aiq_proc = capture_proc = None
        modified = False
        service_stopped = False
        interrupted = False
        config = {'sensor': camera.sensor.name, 'sensor_width': mode.width, 'sensor_height': mode.height,
                  'width': args.width, 'height': args.height, 'fps': args.framerate,
                  'video': camera.video.node, 'action': args.action, 'frames': args.frames,
                  'timeout': args.timeout, 'warmup': args.warmup,
                  'output': str(Path(args.output).resolve()) if args.output else None,
                  'session_iq': str(temp / 'imx219-session.json'), 'ready': str(temp / 'ready'),
                  'result': str(logdir / 'result.json'), 'iq_source': str(profile), 'mode': asdict(mode),
                  'warnings': warnings}
        Path(config['session_iq']).write_text(json.dumps(iq))
        (logdir / 'config.json').write_text(json.dumps(config, indent=2))
        config_path = temp / 'config.json'
        config_path.write_text(json.dumps(config))
        prior_handlers = {}

        def terminate(_signum, _frame):
            nonlocal interrupted
            interrupted = True
            if capture_proc is not None and capture_proc.poll() is None:
                capture_proc.send_signal(signal.SIGINT)

        for sig in (signal.SIGINT, signal.SIGTERM):
            prior_handlers[sig] = signal.signal(sig, terminate)
        try:
            config['fps_control'] = media.command(sys.executable, '-m', 'armsom_camera.aiq',
                                                  '--check', str(config_path)).strip()
            config['independent_capture_pool'] = config['fps_control'] == 'isp30-sysctl_tuning'
            if interrupted:
                raise CameraError('Interrupted before capture started')
            if was_active:
                service_stopped = True
                media.command('systemctl', 'stop', 'rkaiq_3A.service')
            # A manually started AIQ server must not run alongside this worker.
            if subprocess.run(['pgrep', '-x', 'rkaiq_3A_server'], stdout=subprocess.DEVNULL).returncode == 0:
                raise CameraError('An unmanaged rkaiq_3A_server is running; stop it first')
            modified = True
            config['crop'] = media.configure(camera, mode, args.width, args.height)
            media.set_initial_fps(camera, mode, args.framerate)
            (logdir / 'config.json').write_text(json.dumps(config, indent=2))
            config_path.write_text(json.dumps(config))
            aiq_proc = subprocess.Popen([sys.executable, '-m', 'armsom_camera.aiq', str(config_path)],
                                        stdout=aiq_log, stderr=subprocess.STDOUT, start_new_session=True)
            deadline = time.monotonic() + 25
            while not Path(config['ready']).exists():
                if interrupted:
                    raise CameraError('Interrupted before capture started')
                if aiq_proc.poll() is not None or time.monotonic() > deadline:
                    raise CameraError(f'RKAIQ could not start; see {logdir / "aiq.log"}')
                time.sleep(.1)
            media.verify(camera, mode, args.width, args.height)
            if interrupted:
                raise CameraError('Interrupted before capture started')
            capture_proc = subprocess.Popen([sys.executable, '-m', 'armsom_camera.capture', str(config_path)],
                                            stdout=capture_log, stderr=subprocess.STDOUT, start_new_session=True)
            while capture_proc.poll() is None:
                if aiq_proc.poll() is not None:
                    raise CameraError(f'RKAIQ exited during capture; see {logdir / "aiq.log"}')
                time.sleep(.1)
            if capture_proc.returncode:
                raise CameraError(f'Capture failed; see {logdir / "capture.log"}')
            result = json.loads(Path(config['result']).read_text())
            print(f"Captured {result['frames']} frames, {result['width']}x{result['height']}, measured {result['measured_fps']:.2f} FPS", flush=True)
            if config['output']:
                path = Path(config['output'])
                if not path.is_file() or path.stat().st_size == 0:
                    raise CameraError('No output file was created')
                if 'SUDO_UID' in os.environ:
                    os.chown(path, int(os.environ['SUDO_UID']), int(os.environ['SUDO_GID']))
                print(f'Saved: {path}', flush=True)
            return result
        finally:
            stop_process(capture_proc, signal.SIGINT)
            stop_process(aiq_proc)
            errors = []
            if modified:
                for argv in saved:
                    try:
                        media.command(*argv)
                    except (CameraError, subprocess.TimeoutExpired) as exc:
                        errors.append(str(exc))
            if service_stopped:
                try:
                    media.command('systemctl', 'start', 'rkaiq_3A.service')
                except (CameraError, subprocess.TimeoutExpired) as exc:
                    errors.append(str(exc))
            for sig, handler in prior_handlers.items():
                signal.signal(sig, handler)
            if errors:
                (logdir / 'cleanup-errors.log').write_text('\n'.join(errors))
                raise CameraError(f'Could not fully restore the camera; see {logdir / "cleanup-errors.log"}')
