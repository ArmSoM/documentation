"""Public command-line interface; capability discovery precedes mutation."""
import argparse
from dataclasses import asdict
import json
import os
from pathlib import Path
import subprocess
import sys

from . import __version__, media
from .media import CameraError
from .session import capture


def main(argv=None):
    parser = argparse.ArgumentParser(description='ArmSoM IMX219 camera: automatic sensor mode, ISP and 3A setup')
    parser.add_argument('action', nargs='?', choices=['preview', 'still', 'video', 'test'], default='preview')
    parser.add_argument('--version', action='version', version=__version__)
    parser.add_argument('--list-cameras', action='store_true', help='list cameras and driver-reported sensor modes')
    parser.add_argument('--camera', type=int, default=0, help='camera index from --list-cameras (default: 0)')
    parser.add_argument('--width', type=int, help='output width; defaults to 1920 (still: 3280)')
    parser.add_argument('--height', type=int, help='output height; defaults to 1080 (still: 2464)')
    parser.add_argument('--framerate', '--fps', type=int, default=None, help='integer FPS (default: 30; still: 15)')
    parser.add_argument('-t', '--timeout', type=int, default=None, help='duration in ms, 0 = until Ctrl+C; for still: 3A warmup time')
    parser.add_argument('-o', '--output', help='JPEG for still; MP4 for video')
    parser.add_argument('--frames', type=int, default=0, help='optional frame limit for preview/video/test')
    parser.add_argument('--warmup', type=int, default=None, help='frames allowed for 3A before a still (default: 2 seconds)')
    parser.add_argument('--iq-file', help='optional calibrated IQ profile for this sensor/module/SoC')
    parser.add_argument('--dry-run', action='store_true', help='show selected mode without changing the camera')
    parser.add_argument('--force', action='store_true', help='allow overwriting the output file')
    args = parser.parse_args(argv)
    try:
        devices = media.discover()
        if args.list_cameras:
            for index, camera in enumerate(devices):
                print(f'{index}: {camera.sensor.name} -> {camera.video.node} ({camera.isp_graph.device})')
                for mode in media.enumerate_modes(camera.sensor.node):
                    print(f'    {mode.width}x{mode.height}  up to {mode.fps:g} FPS')
            return 0
        if not 0 <= args.camera < len(devices):
            raise CameraError('Camera index out of range; use --list-cameras')
        if (args.width is None) != (args.height is None):
            raise CameraError('Specify --width and --height together')
        args.width = args.width if args.width is not None else (3280 if args.action == 'still' else 1920)
        args.height = args.height if args.height is not None else (2464 if args.action == 'still' else 1080)
        args.framerate = args.framerate if args.framerate is not None else (15 if args.action == 'still' else 30)
        args.timeout = args.timeout if args.timeout is not None else {'preview': 5000, 'test': 5000, 'still': 2000, 'video': 0}[args.action]
        args.warmup = args.warmup if args.warmup is not None else (args.framerate * args.timeout + 999) // 1000
        if min(args.width, args.height, args.framerate) <= 0 or args.width % 2 or args.height % 2:
            raise CameraError('Width and height must be positive even numbers; FPS must be a positive integer')
        if min(args.timeout, args.frames, args.warmup) < 0:
            raise CameraError('Timeout, frame limit and warmup cannot be negative')
        if args.action == 'still' and args.frames:
            raise CameraError('Still capture saves one image; --frames applies to preview/video/test')
        if args.action in ('preview', 'test') and args.output:
            raise CameraError('--output applies to still/video')
        camera = devices[args.camera]
        mode = media.select_mode(media.enumerate_modes(camera.sensor.node), args.width, args.height, args.framerate)
        plan = {'camera': camera.sensor.name, 'sensor': asdict(mode), 'output': [args.width, args.height],
                'fps': args.framerate, 'video': camera.video.node,
                'crop': media.center_crop(mode.width, mode.height, args.width, args.height)}
        if args.dry_run:
            print(json.dumps(plan, indent=2))
            return 0
        if os.geteuid() != 0:
            raise CameraError('Run with sudo -E; configuring the shared ISP and RKAIQ service requires root')
        if args.action in ('still', 'video'):
            args.output = args.output or ('photo.jpg' if args.action == 'still' else 'video.mp4')
            output = Path(args.output)
            extensions = ('.jpg', '.jpeg') if args.action == 'still' else ('.mp4',)
            if output.suffix.lower() not in extensions:
                raise CameraError(f'Output must use {extensions}')
            if output.exists() and not args.force:
                raise CameraError('Output exists; choose another name or use --force')
            if not output.parent.is_dir():
                raise CameraError('Output directory does not exist')
        print(f'{camera.sensor.name}: sensor {mode.width}x{mode.height} -> output {args.width}x{args.height} @ {args.framerate} FPS', flush=True)
        capture(camera, mode, args)
        return 0
    except (CameraError, OSError, subprocess.TimeoutExpired) as exc:
        print(f'armsom-camera: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
