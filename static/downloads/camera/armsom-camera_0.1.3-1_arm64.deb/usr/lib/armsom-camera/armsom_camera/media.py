"""Media graph discovery and V4L2 configuration. No device numbers are fixed."""
from __future__ import annotations

import array
from dataclasses import dataclass, field
import errno
import fcntl
import os
from pathlib import Path
import re
import subprocess


class CameraError(RuntimeError):
    """An actionable camera configuration or capture error."""


def command(*args: str) -> str:
    result = subprocess.run(args, capture_output=True, text=True, timeout=20,
                            env={**os.environ, 'LC_ALL': 'C'})
    if result.returncode:
        raise CameraError(f"{' '.join(args)}: {result.stderr.strip() or result.stdout.strip()}")
    return result.stdout


@dataclass
class Entity:
    name: str
    node: str = ''
    pads: dict[int, str] = field(default_factory=dict)
    links: list[tuple[int, str, int]] = field(default_factory=list)


@dataclass
class Graph:
    device: str
    model: str
    entities: dict[str, Entity]


def parse_graph(device: str, text: str) -> Graph:
    model = re.search(r'^model\s+(.+)$', text, re.M)
    graph = Graph(device, model.group(1).strip() if model else '', {})
    entity = None
    pad = None
    for line in text.splitlines():
        found = re.match(r'- entity \d+: (.+) \(\d+ pads?, \d+ links?\)', line)
        if found:
            entity = Entity(found.group(1))
            graph.entities[entity.name] = entity
            continue
        if entity is None:
            continue
        found = re.search(r'device node name (/dev/\S+)', line)
        if found:
            entity.node = found.group(1)
        found = re.search(r'pad(\d+): (Sink|Source)', line)
        if found:
            pad = int(found.group(1))
            entity.pads[pad] = found.group(2)
        found = re.search(r'-> "(.+)":(\d+) \[([^]]*)\]', line)
        if found and 'ENABLED' in found.group(3):
            entity.links.append((pad, found.group(1), int(found.group(2))))
    return graph


@dataclass
class Camera:
    sensor: Entity
    sensor_graph: Graph
    isp_graph: Graph
    bridge: Entity
    isp: Entity
    video: Entity


def cameras(graphs: list[Graph]) -> list[Camera]:
    result = []
    for graph in graphs:
        for sensor in graph.entities.values():
            if not re.search(r'(^|_)imx219\s', sensor.name):
                continue
            matches = []
            for isp_graph in graphs:
                isp = isp_graph.entities.get('rkisp-isp-subdev')
                video = isp_graph.entities.get('rkisp_mainpath')
                if not isp or not video:
                    continue
                bridge = isp_graph.entities.get(graph.model)
                if isp_graph is graph:
                    bridge = sensor
                if bridge and any(dst == isp.name and sink == 0
                                  for _, dst, sink in bridge.links):
                    matches.append(Camera(sensor, graph, isp_graph, bridge, isp, video))
            if len(matches) != 1:
                raise CameraError(f'{sensor.name}: expected one enabled ISP route, found {len(matches)}')
            result.extend(matches)
    return sorted(result, key=lambda item: item.sensor.name)


def discover() -> list[Camera]:
    graphs = [parse_graph(str(p), command('media-ctl', '-d', str(p), '-p'))
              for p in sorted(Path('/dev').glob('media[0-9]*'))]
    result = cameras(graphs)
    if not result:
        raise CameraError('No IMX219 -> RKISP route found. Check the camera cable and boot overlay.')
    return result


@dataclass(frozen=True)
class Mode:
    width: int
    height: int
    fps: float
    code: int


def enumerate_modes(node: str) -> list[Mode]:
    """Read returned dimensions too: the vendor driver enumerates by mode index."""
    fmt = command('v4l2-ctl', '-d', node, '--get-subdev-fmt=0')
    code = int(re.search(r'Mediabus Code\s*:\s*(0x[0-9a-f]+)', fmt, re.I).group(1), 16)
    sizes = command('v4l2-ctl', '-d', node, f'--list-subdev-framesizes=pad=0,code={code}')
    result = {}
    with open(node, 'rb', buffering=0) as device:
        for width, height in re.findall(r'Size Range: (\d+)x(\d+)', sizes):
            for index in range(128):
                # linux/v4l2-subdev.h: 16 u32s, ENUM_FRAME_INTERVAL = _IOWR('V',75,64).
                data = array.array('I', [index, 0, code, int(width), int(height), 0, 0, 1] + [0] * 8)
                try:
                    fcntl.ioctl(device.fileno(), 0xC040564B, data, True)
                except OSError as exc:
                    if exc.errno == errno.EINVAL:
                        break
                    raise
                if data[5] == 0:
                    raise CameraError('Sensor returned a zero frame interval')
                mode = Mode(data[3], data[4], data[6] / data[5], data[2])
                key = (mode.width, mode.height, mode.code)
                if key not in result or mode.fps > result[key].fps:
                    result[key] = mode
    if not result:
        raise CameraError('Sensor did not enumerate usable modes')
    return sorted(result.values(), key=lambda m: (m.width * m.height, m.width))


def select_mode(modes: list[Mode], width: int, height: int, fps: int) -> Mode:
    eligible = [m for m in modes if m.fps + 0.001 >= fps and m.width >= width and m.height >= height]
    if not eligible:
        available = ', '.join(f'{m.width}x{m.height}@{m.fps:g}' for m in modes)
        raise CameraError(f'{width}x{height}@{fps} cannot be delivered without upscaling or exceeding the sensor limit. Modes: {available}')
    # Exact size first; otherwise minimise aspect crop, then sensor readout area.
    return min(eligible, key=lambda m: (m.width != width or m.height != height,
                                       abs(m.width / m.height - width / height),
                                       m.width * m.height))


def center_crop(sw: int, sh: int, width: int, height: int) -> tuple[int, int, int, int]:
    if sw * height > sh * width:
        cw, ch = (sh * width // height) & ~1, sh
    else:
        cw, ch = sw, (sw * height // width) & ~1
    return ((sw - cw) // 2 & ~1, (sh - ch) // 2 & ~1, cw, ch)


def pad_format(graph: Graph, entity: Entity, pad: int, value: str) -> None:
    command('media-ctl', '-d', graph.device, '-V', f'"{entity.name}":{pad} [{value}]')


def configure(camera: Camera, mode: Mode, width: int, height: int) -> dict:
    codes = command('v4l2-ctl', '-d', camera.sensor.node, '--list-subdev-mbus-codes=0')
    names = {int(code, 16): name for code, name in
             re.findall(r'(0x[0-9a-f]+): MEDIA_BUS_FMT_(\w+)', codes, re.I)}
    if mode.code not in names:
        raise CameraError('Cannot resolve the selected sensor media-bus format')
    raw = f'fmt:{names[mode.code]}/{mode.width}x{mode.height} field:none'
    pad_format(camera.sensor_graph, camera.sensor, 0, raw)
    # Configure receiver sinks along enabled links. Their drivers propagate the
    # sensor format internally; CSI virtual-channel source pads are not writable.
    todo, seen = [camera.sensor], {camera.sensor.name}
    while todo:
        entity = todo.pop(0)
        for _, name, sink in entity.links:
            dest = camera.sensor_graph.entities.get(name)
            if dest and dest.node.startswith('/dev/v4l-subdev') and name not in seen:
                if dest.name == camera.isp.name:
                    continue
                pad_format(camera.sensor_graph, dest, sink, raw)
                seen.add(name)
                todo.append(dest)
    if camera.bridge is not camera.sensor:
        pad_format(camera.isp_graph, camera.bridge, 0, raw)
    pad_format(camera.isp_graph, camera.isp, 0, raw)
    pad_format(camera.isp_graph, camera.isp, 0,
               f'crop:(0,0)/{mode.width}x{mode.height}')
    pad_format(camera.isp_graph, camera.isp, 2,
               f'fmt:YUYV8_2X8/{mode.width}x{mode.height} field:none')
    left, top, cw, ch = center_crop(mode.width, mode.height, width, height)
    command('v4l2-ctl', '-d', camera.video.node,
            f'--set-selection=target=crop,left={left},top={top},width={cw},height={ch}')
    command('v4l2-ctl', '-d', camera.video.node,
            f'--set-fmt-video=width={width},height={height},pixelformat=NV12')
    verify(camera, mode, width, height)
    return {'left': left, 'top': top, 'width': cw, 'height': ch}


def verify(camera: Camera, mode: Mode, width: int, height: int) -> None:
    for node, sw, sh, option in (
        (camera.sensor.node, mode.width, mode.height, '--get-subdev-fmt=0'),
        (camera.isp.node, mode.width, mode.height, '--get-subdev-fmt=0'),
        (camera.video.node, width, height, '--get-fmt-video'),
    ):
        text = command('v4l2-ctl', '-d', node, option)
        found = re.search(r'Width/Height\s*:\s*(\d+)/(\d+)', text)
        if not found or tuple(map(int, found.groups())) != (sw, sh):
            raise CameraError(f'{node}: driver changed the requested dimensions: {text.strip()}')


def set_initial_fps(camera: Camera, mode: Mode, fps: int) -> None:
    controls = command('v4l2-ctl', '-d', camera.sensor.node, '--list-ctrls')
    found = re.search(r'vertical_blanking.*?min=(\d+) max=(\d+)', controls)
    if not found:
        raise CameraError('IMX219 does not expose vertical_blanking')
    low, high = map(int, found.groups())
    vblank = round((mode.height + low) * mode.fps / fps) - mode.height
    if not low <= vblank <= high:
        raise CameraError(f'{fps} FPS exceeds the sensor frame-length range for this mode')
    command('v4l2-ctl', '-d', camera.sensor.node, f'--set-ctrl=vertical_blanking={vblank}')


def snapshot(camera: Camera) -> list[tuple[str, ...]]:
    """Save the writable formats/crops touched by this backend for restoration."""
    saved = []
    entries = [(camera.sensor_graph, camera.sensor, 0)]
    todo, seen = [camera.sensor], {camera.sensor.name}
    while todo:
        entity = todo.pop(0)
        for _, name, sink in entity.links:
            dest = camera.sensor_graph.entities.get(name)
            if dest and dest.node.startswith('/dev/v4l-subdev') and name not in seen and name != camera.isp.name:
                entries.append((camera.sensor_graph, dest, sink))
                seen.add(name)
                todo.append(dest)
    if camera.bridge is not camera.sensor:
        entries.append((camera.isp_graph, camera.bridge, 0))
    entries.extend([(camera.isp_graph, camera.isp, 0), (camera.isp_graph, camera.isp, 2)])
    for graph, entity, pad in entries:
        text = command('media-ctl', '-d', graph.device, '--get-v4l2', f'"{entity.name}":{pad}')
        fmt = re.search(r'fmt:([^/]+)/([0-9]+x[0-9]+)', text)
        if not fmt:
            raise CameraError(f'Cannot save {entity.name}:{pad} format')
        saved.append(('media-ctl', '-d', graph.device, '-V',
                      f'"{entity.name}":{pad} [fmt:{fmt[1]}/{fmt[2]} field:none]'))
        crop = re.search(r'(?<![.\w])crop:(\([^)]*\)/\d+x\d+)', text)
        if crop and entity is camera.isp:
            saved.append(('media-ctl', '-d', graph.device, '-V', f'"{entity.name}":{pad} [crop:{crop[1]}]'))
    text = command('v4l2-ctl', '-d', camera.video.node, '--get-fmt-video')
    size = re.search(r'Width/Height\s*:\s*(\d+)/(\d+)', text)
    fourcc = re.search(r"Pixel Format\s*:\s*'([^']+)'", text)
    crop = command('v4l2-ctl', '-d', camera.video.node, '--get-selection=target=crop')
    values = {key.lower(): value for key, value in
              re.findall(r'(left|top|width|height)[= ]+(-?\d+)', crop, re.I)}
    if len(values) != 4 or not size or not fourcc:
        raise CameraError('Cannot save the original ISP output configuration')
    saved.append(('v4l2-ctl', '-d', camera.video.node, '--set-selection=target=crop,' +
                  ','.join(f'{key}={value}' for key, value in values.items())))
    saved.append(('v4l2-ctl', '-d', camera.video.node,
                  f'--set-fmt-video=width={size[1]},height={size[2]},pixelformat={fourcc[1]}'))
    blank = command('v4l2-ctl', '-d', camera.sensor.node, '--get-ctrl=vertical_blanking')
    saved.append(('v4l2-ctl', '-d', camera.sensor.node,
                  '--set-ctrl=vertical_blanking=' + blank.strip().rsplit(' ', 1)[-1]))
    return saved
