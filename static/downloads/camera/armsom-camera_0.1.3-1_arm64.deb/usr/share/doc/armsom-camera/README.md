# ArmSoM Camera

Unified IMX219 capture for the ArmSoM vendor RKISP/RKAIQ stack. Version 0.1.2 is
validated on CM7S / RK3588S with the SDK's Debian 12 stack; CM5 / RK3576 hardware
acceptance used 0.1.1, with its direct frame-rate API covered by regression tests
in 0.1.2. It is a userspace
frontend, not a libcamera pipeline handler or a replacement IMX219 driver.

## Commands

```sh
armsom-camera --list-cameras
sudo -E armsom-camera preview --width 1640 --height 1232 --framerate 30 -t 0
sudo armsom-camera still --width 3280 --height 2464 --framerate 15 -o photo.jpg
sudo armsom-camera video --width 1920 --height 1080 --framerate 30 -t 10000 -o video.mp4
sudo armsom-camera test --width 1280 --height 720 --framerate 30 -t 5000
armsom-camera preview --width 1280 --height 720 --framerate 30 --dry-run
```

Enable the IMX219 boot overlay and connect the camera before using these tools.
Changing resolution afterwards needs neither a reboot nor a driver rebuild.
Run preview in a terminal on the board's graphical desktop. `sudo -E` preserves
the display connection. Still capture and recording also work over serial/SSH.
Preview uses `glimagesink` with clock synchronization and defaults to EGL/OpenGL
ES for the vendor Mali driver. NV12 conversion and scaling run on the GPU.
The viewfinder is limited to 1280x960, preserving aspect ratio to within even-pixel
rounding. This display scaling does not change the requested sensor/ISP output,
JPEG or recording resolution. It prevents oversized native-resolution windows.
This avoids the Xv path automatically selected by the previous release, which
produced horizontal tearing on the tested CM5 desktop. Screen presentation is
handled by EGL and the desktop compositor; GStreamer clock sync alone is not
a vertical-sync switch. `result.json` also records the sink's rendered/dropped
frame counts; these exclude frames discarded by the bounded preview queue.
`-t` is milliseconds; zero runs preview/video until Ctrl+C. For still capture,
`-t` specifies the 3A settling time (default 2000 ms), followed by exactly one
JPEG. `--warmup` overrides the still settling time with an explicit frame count.
Video is H.264 in MP4, finalized on normal exit or Ctrl+C. Existing output files
are protected unless `--force` is passed. `--camera N` selects a listed camera.

The current driver reports 3280x2464 at 15 FPS and 1640x1232, 1920x1080 and
640x480 at 30 FPS. These are driver timing limits, not the sensor's theoretical
maximum. Output dimensions must be even; this version accepts integer FPS.
Unavailable size/FPS combinations are rejected, not silently upscaled or reduced
to a different frame rate. Exact sensor sizes take priority; otherwise the tool
minimises aspect-ratio mismatch and then readout area among feasible modes.
The 1080p mode crops the sensor and has a narrower field of view than full-frame
or 1640x1232 binning. The ISP performs final crop/scale to the requested size.

## Installation and SDK integration

The SDK carries one package, `debian12/packages/arm64/camera/armsom-camera_0.1.3-1_arm64.deb`.
`mk-bookworm-rootfs.sh` installs it through APT inside the image, after the
platform's RKAIQ and GStreamer packages. The package declares its dependencies
and owns only the application, its manual and documentation. It installs no
systemd service, timer, desktop autostart, driver, IQ or boot configuration.
Installing the package does not start capture or change the existing 3A service.

The normal SDK workflow is unchanged. From the SDK root, choose the board and
Debian desktop/server configuration, then build:

```sh
./build.sh chip
./build.sh
```

No extra selection is required. `ARMSOM_CAMERA` defaults to `auto` and controls
installation when a Debian 12 rootfs is generated:

| Value | Behaviour |
| --- | --- |
| `auto` (default) | Install on arm64 RK3576/RK3588/RK3588S desktop images (GNOME/XFCE/LXDE); skip server and other platforms. |
| `1` | Install on a supported arm64 platform, including server images. |
| `0` | Skip the application and its explicit dependency installation. |

An invalid value, unsupported forced platform or missing enabled package fails
before the existing rootfs is replaced. Other SDK packages may still need some
of the same dependencies when this application is disabled. This switch affects
new rootfs builds, not an already running board. To override the default for
one build, replace the second command above with one of these:

```sh
ARMSOM_CAMERA=1 ./build.sh  # Install, including on a supported server image.
ARMSOM_CAMERA=0 ./build.sh  # Skip the camera application.
```

The SDK reuses an existing rootfs image when it prints `Already Exists IMG`.
In that case, changing this switch does not change the cached image. Move the
specific rootfs image named in the build log to a backup location before
building again to regenerate it. No extra top-level build menu is added.

For an existing compatible image, copy the DEB to the board and install it:

```sh
sudo apt install --no-remove ./armsom-camera_0.1.3-1_arm64.deb
armsom-camera --version
# Stop any capture before upgrading or removing the package.
sudo apt remove armsom-camera
```

Do not extract a DEB directly into `/`. APT/dpkg tracks the version and files.
The DEB can replace the earlier tar-installed application at the same paths;
back up local application edits first. Removal cleans application bytecode,
while retaining captured media and diagnostic logs. It does not remove or
reconfigure the platform's camera driver, IQ or RKAIQ service.

Keep the image's SDK-provided RKAIQ and `mpph264enc`. RK3588 and RK3588S use the
SDK's same RK3588 RKAIQ package. CM7S (RK3588S) is the current test board; AIM7
hardware and Ubuntu still need separate acceptance. CM5 was previously tested
on GNOME and XFCE/X11, and CM7S on XFCE/X11. The build selector is not a claim
that every desktop, board or future ABI combination has been tested.

The launcher is installed in `/usr/bin`, modules in `/usr/lib/armsom-camera`,
and documentation in `/usr/share/doc/armsom-camera`. Rebuild inputs, including
tests and `build-deb.py`, are kept in `source.tar.gz` inside that documentation
directory so that the SDK does not need another loose source tree. On a Linux
build host with Python 3.10+ and `dpkg-deb`, extract the source archive, edit it,
run its tests, then build a new package:

```sh
PYTHONPATH=. python3 -m unittest discover -s tests -v
python3 build-deb.py --output-dir ../packages
```

The default DEB maintainer matches the SDK Git author; `--maintainer` can override
it. Packaging does not assign a new redistribution license to the application.

## Calibration and frame rate

The original `/etc/iqfiles/imx219_*.json` is never overwritten. Each session
copies its calibration into a private directory in `/run`, adjusts only the
sensor-mode resolution, AE fixed-FPS fields and lower FPS bound if necessary,
and passes the profile to RKAIQ's public `preInit/init/prepare/start` APIs.
`prepare` receives sensor dimensions, not the scaled output size. Frame rate
is also applied via `rk_aiq_uapi2_setFrameRate` where available. For the ISP30
SDK without that symbol, the public `rk_aiq_uapi2_sysctl_tuning` JSON API sets
`/ae_calib/CommCtrl/AecFrameRateMode` after init and before prepare. Its
`isFpsFix` value must be numeric `1`; this parser does not enable fixed FPS
from JSON `true`. Required symbols and the fallback IQ schema are checked in
an isolated process before stopping 3A. Initial VBLANK is set before streaming.
No frame duplication or `videorate` is used to simulate sensor FPS.

The ISP30 capture path isolates source buffer allocation from downstream
encoders using `identity drop-allocation=true`. On the tested stack, sharing
the negotiated two-buffer pool dropped every third frame; independent source
allocation restores 30 FPS recording and 15 FPS full-resolution still capture.
The CM5 direct-API path retains its previous buffer negotiation.

You do not need a different manually edited IQ file for every output resolution.
For ISP30, an existing mode-specific LSC configuration takes priority. The SDK
IMX219 1640x1232 mode is full-FOV 2x2 binning: if only 3280x2464 LSC is present,
the application halves the mesh coordinates in its private profile and retains
the calibrated gain samples. This is a geometry mapping, not a new calibration.
It is not applied to cropped modes. If a mode still has no usable LSC geometry
(such as 640x480 with the supplied IQ), LSC is disabled for that session with a
warning; otherwise this ISP30 library can produce black frames. Lens shading
may remain in those modes. The original file and its tables are never changed.

On CM7S, a matched 3280x2464 @15 comparison with the image's original 3A service
showed comparable brightness and static detail. With LSC retained and the same
smaller viewfinder, the user also confirmed normal 1640x1232 @30 preview. Avoid
comparing differently sized windows as an image-quality test. Full resolution
retains more source detail; 1640x1232 offers a higher frame rate with full FOV.

Distortion correction and noise/colour calibration can also differ between
sensor readout modes. For a separately calibrated mode, install a file
at `/etc/iqfiles/armsom-camera/imx219-WIDTHxHEIGHT.json`, or pass `--iq-file`.
These dimensions name the sensor mode. Unsupported IQ schemas are rejected.

## Resource ownership and diagnostics

The frontend takes an exclusive lock and rejects other processes using camera
nodes. The SDK 3A daemon manages multiple ISPs, so this release permits one
capture session at a time. It temporarily stops the managed `rkaiq_3A.service`,
owns one isolated RKAIQ worker, then restores prior formats, crop, VBLANK and
the previous service state. A manually launched 3A server is rejected.
Workers have readiness/stall timeouts and monitor their parent. Normal exit,
SIGINT, SIGTERM and caught errors run cleanup; SIGKILL/power loss cannot execute
parent cleanup (restart `rkaiq_3A.service` if necessary).

Logs and effective configuration are retained in `/var/log/armsom-camera/`.
On each capture start and exit, generated session directories are pruned to
keep at most 20 sessions and a 64 MiB total-size threshold, oldest first; the
current session is protected. Each of `aiq.log` and `capture.log` rotates at
1 MiB and retains one `.1` backup. During capture the current logs can add up to
4 MiB beyond the historical threshold. Native output is continuously drained,
even if log storage fails, so long runs do not grow a single log indefinitely.
Cleanup runs only when the application is explicitly used; no background timer
is installed. Unrelated directories and symlinks are not pruned. Save needed
failure reports elsewhere before they become old history.
`result.json` records negotiated dimensions, frame count and measured arrival
FPS; this is not a calibration-quality report. Files `aiq.log`, `capture.log`
and any `cleanup-errors.log` identify the failing stage. The RKAIQ worker uses
the root cgroup because this SDK's realtime statistics thread needs it with
`CONFIG_RT_GROUP_SCHED`, matching the existing 3A service workaround.

Source modules separate media discovery/configuration (`media.py`), calibration
selection (`iq.py`), native AIQ ownership (`aiq.py`), GStreamer (`capture.py`),
session lifecycle (`session.py`) and the public CLI (`cli.py`). The ctypes
binding uses the SDK's public uAPI2 opaque-pointer functions and the exact
`frameRateInfo_t { opMode_t mode; unsigned int fps; }` ABI; algorithm-specific
structs are deliberately not exposed. The ISP30 fallback uses JSON rather than
reproducing the version-dependent `Uapi_ExpSwAttrV2_t` layout. Frame interval enumeration reads returned
dimensions, because this vendor IMX219 driver indexes its full mode table.

## Verification

```sh
PYTHONPATH=. python3 -m unittest discover -s tests -v
```

Hardware acceptance covers each native mode, ISP scaling, 25 FPS, JPEG, MP4,
desktop preview, rejected requests, interruption and service restoration.
See `VALIDATION.md` for the measured results and remaining scope.

## Implementation references

- [Raspberry Pi rpicam-apps mode selection and lifecycle](https://github.com/raspberrypi/rpicam-apps/blob/main/core/rpicam_app.cpp): enumerate capabilities and choose modes in userspace, separately from output configuration.
- [Radxa ZERO 3 camera usage](https://docs.radxa.com/en/zero/zero3/accessories/camera): vendor Rockchip images use an enabled overlay plus V4L2/GStreamer.
- [Luckfox SDK rkisp demo](https://github.com/LuckfoxTECH/luckfox-pico/blob/main/media/isp/release_camera_engine_rkaiq_rv1106_arm-rockchip830-linux-uclibcgnueabihf/rkisp_demo/demo/rkisp_demo.cpp): vendor RKAIQ application integration. Its different ISP/ABI is not substituted for CM5's library.
- [Linux V4L2 subdevice API](https://docs.kernel.org/userspace-api/media/v4l/dev-subdev.html): configure coherent formats across the media pipeline.
- [Raspberry Pi ALSC](https://github.com/raspberrypi/libcamera/blob/main/src/ipa/rpi/controller/rpi/alsc.cpp): calibration geometry follows sensor crop/scale; the bounded full-FOV mapping here uses the SDK's own gain tables.
- [GStreamer identity](https://gstreamer.freedesktop.org/documentation/coreelements/identity.html) and [glimagesink](https://gstreamer.freedesktop.org/documentation/opengl/glimagesink.html): allocation-query isolation and GPU preview rendering.
- The current SDK's installed `uAPI2/rk_aiq_user_api2_sysctl.h`, `rk_aiq_user_api2_imgproc.h`, and `rk_aiq_user_api_common.h` define the binding signatures.

The implementation is original; these references informed the architecture and
interfaces rather than being copied into a monolithic shell script.
