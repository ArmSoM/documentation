# CM5 hardware acceptance — 2026-11-17

Device: ArmSoM CM5 IO / RK3576, Debian 12, kernel
`6.1.118-rk3576 #277`. Board access and tests used the COM4 serial console at
1,500,000 baud. IMX219 was enabled with the existing CAM0 overlay, then rebooted;
the previous boot configuration remains backed up in `/boot/uEnv/`.

The unchanged kernel reports four RAW10 sensor modes. The frontend dynamically
found sensor `m01_b_imx219 4-0010`, CIF `/dev/media0`, ISP `/dev/media1` and main
output `/dev/video11`. No kernel driver, device-tree source or original IQ file
was changed by the capture implementation.

## Capture results

| Action / requested output | Selected sensor mode | Frames | Measured FPS |
| --- | --- | ---: | ---: |
| Test 1920×1080 @30 | 1920×1080 | 126 | 30.01 |
| Test 1640×1232 @30 | 1640×1232 | 81 | 30.01 |
| Test 1280×720 @30 | 1920×1080, ISP scaling | 81 | 30.01 |
| Test 1920×1080 @25 | 1920×1080 | 68 | 25.00 |
| Test 640×480 @30 | 640×480 | 82 | 30.00 |
| Still 3280×2464 @15 | 3280×2464 | 31 including 30 warmup frames | 15.01 |
| MP4 1920×1080 @30 | 1920×1080 | 111 | 30.01 |
| Desktop preview 1280×720 @30 | 1920×1080, ISP scaling | 126 | 30.01 |
| Installed CLI 1024×768 @30 | 1640×1232, ISP crop/scale | 81 | 30.00 |

`ffprobe` identified the recording as H.264, 1920×1080, 111 frames and 3.698 s
in an MP4 container. The requested recording timer was 3500 ms; the 250 ms
watchdog and EOS drain add a small end-of-recording margin. JPEG was identified
as one 3280×2464 image and visually inspected through a scaled copy. Scene
orientation follows the physical camera mounting; no rotation was added.
Preview used the board's existing X11 desktop at `DISPLAY=:0` and exited
normally. The pipeline result confirms captured preview frames; no external
monitor photograph was taken.

## Error and lifecycle checks

- 3280×2464 @30 is rejected before stopping 3A; camera formats, original IQ
  hash and the 3A service PID remain unchanged.
- A second capture session is rejected while the first owns the lock.
- SIGINT during indefinite recording produces a readable 1280×720 H.264/MP4
  containing 74 frames, and restores original formats/crop and active 3A service.
- Terminating the AIQ worker during capture makes the frontend fail explicitly,
  stop capture and restore original formats/crop and active 3A service.
- No `armsom_camera` worker remained after the installed-command check.
- Original IQ SHA256 before/after the lifecycle tests:
  `c5538677c3bd3e98fac239b406cd0df1090b3c3463f2a8817e54e90a3bb305c3`.
- All 13 host regression tests passed on both the build server and CM5. They
  cover mode/FPS constraints, output crop, topology association and IQ schema/
  calibration preservation. Rootfs script syntax, installer staging and Python
  byte compilation passed. Both changed tutorial sections compiled as MDX;
  repository whitespace checks passed.

## Delivery and limits

Source bundle: `/home/donleon/code/armsom-sdk/debian12/packages/arm64/camera/armsom-camera-0.1.1.tar.gz`.
Integration: `debian12/mk-bookworm-rootfs.sh` temporarily extracts the bundle,
installs the application after overlay copy, removes the temporary extraction,
and includes runtime dependencies for desktop/headless images. Other
pre-existing changes in that script were preserved. The original script is
backed up at `/home/donleon/armsom-camera-backup-20261117-173714/`.
CM5 has `/usr/bin/armsom-camera` version 0.1.1 and its package installed.
The SDK rootfs image itself was not rebuilt or flashed as part of this change.

The archive replaces the loose SDK source directory; modules, tests and
documentation remain available inside it. Installed paths are unchanged.
Packaging verification covers
archive contents, all 13 regression tests, staged installation, the build hook's
failure propagation and temporary-directory cleanup.

## Preview display correction — 0.1.1

The user reported horizontal discontinuities during motion. Their previous
1640x1232 and 3280x2464 previews delivered 30.00 and 15.00 input FPS respectively.
`autovideosink` selected `xvimagesink`; Xorg logged
`glamor xv failed to render dma image` during those sessions. Input frame counts
alone did not establish correct on-screen presentation in the original acceptance.

Preview now uses clock-synchronized `glimagesink`, defaulting to EGL/GLES, with
NV12 conversion and scaling on the GPU. The board reported `GL_VENDOR: ARM` and
`GL_RENDERER: Mali-G52`. The same sensor/ISP/IQ configuration is used. The build
adds `gstreamer1.0-gl`; still, recording and headless capture paths are unchanged.

| Corrected preview | Input frames | Input FPS | Sink rendered | Sink late drops |
| --- | ---: | ---: | ---: | ---: |
| 1640x1232 @30, 4 s | 125 | 29.99 | 123 | 0 |
| 3280x2464 @15, 4 s | 62 | 15.01 | 59 | 1 |

Both runs ended normally and restored the active 3A service. No new Xv rendering
errors occurred in the full-resolution run. Counts can differ because the
two-buffer preview queue discards old frames; sink statistics do not include
those drops and do not measure physical scanout. In a subsequent 60-second
1640x1232 @30 display comparison, the user moved objects and explicitly confirmed
that the horizontal discontinuities disappeared. No IMX219 driver, IQ calibration
or desktop-wide configuration change was needed.

Tutorial source was updated in both locales of the local documentation checkout;
the live documentation website was not published. The published section anchors
were preserved.

This acceptance is for one IMX219 stream on this CM5 and matching RKAIQ version.
Other SoCs/images, simultaneous multi-camera capture, long-duration stability and
professional image-quality calibration are outside this validation. Existing
vendor RKAIQ logs emit pool-in-use messages during deinit; cleanup completed,
workers exited and repeated capture succeeded. Changing profile dimensions does
not regenerate LSC, distortion or noise calibration tables.

Detailed session logs and per-session `config.json` / `result.json` remain on the
board under `/var/log/armsom-camera/`. Automated failure-case results are in
`/tmp/imx219-acceptance.json`. Local copies are in the accompanying validation
artifact archive.

# CM7S / ISP30 acceptance — 0.1.2, 2026-11-17

Device: ArmSoM RK3588S CM7S, Debian 12 XFCE/X11, kernel
`6.1.118-rk3588 #268`, Python 3.11.2, Mali-G610. Access used COM4 at
1,500,000 baud. The existing IMX219 CS0 overlay was already enabled.
Discovery found `m01_b_imx219 4-0010`, media0/media1 and video11. RKAIQ reports
v5.0x3.0 / ISP30 (2023-09-07). The SDK uses the same RK3588 RKAIQ package for
RK3588 and RK3588S; this is not a physical AIM7 acceptance.

## Compatibility corrections

- This library lacks `rk_aiq_uapi2_setFrameRate`. The public `sysctl_tuning`
  JSON API applies fixed FPS between init and prepare, following the vendor
  `rkisp_demo` sequence. It uses numeric `isFpsFix: 1`: JSON `true` was parsed
  without an error but left fixed FPS disabled. A temporary helper compiled
  against the board's own AE headers confirmed this by reading the attribute.
  That helper is not shipped; the application does not bind AE struct layouts.
- Source allocation is isolated using GStreamer's `identity drop-allocation`.
  The original negotiated two-buffer encoder pool lost every third frame;
  the corrected JPEG/MP4 path reaches the requested rate without duplicating
  frames. This allocation change is limited to the ISP30 fallback backend.
- The supplied IQ has LSC geometry for 3280x2464 and 1920x1080. Enabling LSC
  without matching 1640x1232 geometry produced black pixels, not merely a black
  preview window. The known full-FOV 2x2 mode now derives half-size coordinates
  from the full-frame mesh, preserving the gain samples. Existing matching
  calibration takes priority. The cropped 640x480 mode cannot reuse this map;
  it disables LSC in the private profile with an explicit warning.
- Preview uses the existing clock-synchronized EGL/GLES presenter and now
  bounds the GPU-scaled viewfinder to 1280x960. Requested capture dimensions
  and saved JPEG/MP4 dimensions remain unchanged. Even-pixel rounding produces
  a 1276x960 viewfinder for both 4:3 native modes on this test.

## Final-source capture results

| Action / requested output | Frames | Measured input FPS |
| --- | ---: | ---: |
| Test 1640x1232 @30 | 80 | 30.01 |
| Test 1920x1080 @25 | 67 | 25.00 |
| Test 1280x720 @30 (ISP scaling) | 81 | 30.01 |
| Test 640x480 @30 | 81 | 30.01 |
| Test 3280x2464 @10 | 27 | 10.00 |
| JPEG 3280x2464 @15, 30 warmup frames | 31 | 15.01 |
| JPEG 640x480 @30, 60 warmup frames | 61 | 30.00 |
| H.264/MP4 1920x1080 @30 | 110 | 30.01 |
| Preview 1640x1232 @30, 6 s | 183 | 29.84 |
| Preview 3280x2464 @15, 6 s | 91 | 14.84 |

The two short previews reported respectively 180/89 rendered frames and one
late sink drop each, including startup. The 1080p MP4 contains 110 frames over
3.666 s (ffprobe average 55000/1833 FPS). JPEG dimensions were verified;
the 640x480 image was visually checked and contains a scene rather than black
pixels. Earlier full-resolution JPEGs were also visually inspected. These
counts measure delivery, not professional image-quality calibration.

## Matched visual comparison

The user initially reported dark subjects and soft edges in the smaller mode.
Disabling LSC fixed black output but was insufficient for satisfactory shading.
Retaining mapped LSC improved numerical brightness: a paired 1640x1232 @15
JPEG and downscaled full-resolution @15 JPEG both had mean 8-bit luma 105.5 in
the static test scene, versus 92.2 with LSC disabled. This statistic alone did
not establish equivalent perceived quality.

The image's original 3A service was then used at 3280x2464 @15 with the original
IQ and a 1230x924 GPU viewfinder. The user found this clearly brighter/sharper
than the earlier oversized small-mode preview. Switching to the new application
at the same sensor mode, FPS and viewfinder size produced user-confirmed
comparable brightness and static edges. Switching back to 1640x1232 @30 with
mapped LSC and the same viewfinder produced user-confirmed normal appearance
with no obvious difference. The user had also confirmed no horizontal tearing
during the corrected 1640x1232 preview. No exposure bias, sharpness strength,
desktop colour setting, original IQ or driver change was needed.

The comparison controls size and mode separately; it does not claim identical
pixel-level detail between 8 MP readout and 2 MP binning, or calibrated image
quality for every lighting condition. The final application uses the bounded
1276x960 window rather than the diagnostic 1230x924 size.

## Lifecycle, delivery and limits

The final source passed 24 unit tests on CM7S. Hardware checks rejected 8 MP @30
and unsupported ISP schema before stopping 3A, preserving its PID. Concurrent
capture was rejected. SIGINT finalized a readable 69-frame 1280x720 MP4.
Terminating the AIQ worker failed explicitly and restored configuration.
After every final capture/error check, all saved media formats/crops/VBLANK
matched the baseline, the 3A service was active and no application worker
remained. Original IQ SHA256 stayed:
`60e3987d9d22e7f214b725e684d1d3b9a54a9b7dc3323036413dec378673c64c`.

Release bundle: `debian12/packages/arm64/camera/armsom-camera-0.1.2.tar.gz`.
It replaces 0.1.1; the rootfs hook changes only the two version references.
The 12-file archive keeps source, tests and documentation together. Build-side
verification runs the 24 tests, Python compilation, shell syntax, staged install,
and the hook's failure propagation/temporary-directory cleanup. The rootfs image
itself is not rebuilt. Documentation changes are local source edits, not a live
website publication.

CM5's prior 0.1.1 hardware acceptance is recorded above; 0.1.2 tests verify the
direct API remains preferred, but CM5 has not been physically retested with the
new viewfinder. AIM7 hardware, Ubuntu, Debian 11, Wayland, simultaneous cameras
and long-duration stability remain outside this acceptance. The 640x480 LSC
fallback can retain lens shading and is not advertised as calibrated quality.

Board evidence: `/tmp/cm7s-camera-acceptance/final/report.json` and the referenced
`/var/log/armsom-camera/` directories. Local report:
`output/cm7s-camera-final-validation.json`. Board log directory dates reflect an
incorrect board clock; the acceptance date above follows the host clock.

Design references are linked in `README.md`: Rockchip's public tuning API
sequence, Raspberry Pi's mode-dependent ALSC geometry, and GStreamer's buffer
allocation and OpenGL rendering interfaces.
